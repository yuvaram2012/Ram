from django.apps import AppConfig


class KrishaAppConfig(AppConfig):
    name = 'krisha_app'
